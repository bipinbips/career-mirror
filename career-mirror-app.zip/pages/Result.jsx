import { useEffect, useState } from 'react';

export default function Result() {
  const [summary, setSummary] = useState('');

  useEffect(() => {
    const storedAnswers = JSON.parse(localStorage.getItem('careerAnswers'));

    if (!storedAnswers) return;

    const score = storedAnswers.reduce((acc, ans) => {
      switch (ans) {
        case 'Stay calm':
        case 'Always':
        case 'Logically':
        case 'Very':
        case 'Learn and move on':
          return acc + 3;
        case 'Try again':
        case 'Sometimes':
        case 'By asking others':
        case 'Average':
          return acc + 2;
        case 'Get angry':
        case 'Rarely':
        case 'Emotionally':
        case 'Not much':
        case 'Get demotivated':
          return acc + 1;
        default:
          return acc;
      }
    }, 0);

    let result = '';
    if (score >= 13) {
      result = 'You have a strong and resilient personality. Careers in leadership, entrepreneurship, or strategic management could suit you well.';
    } else if (score >= 9) {
      result = 'You have a balanced personality. Careers in analysis, consulting, or customer relations may be a good fit.';
    } else {
      result = 'You might thrive in supportive or creative roles. Careers in design, arts, or assistant roles could suit you.';
    }

    setSummary(result);
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-green-100 p-6">
      <div className="max-w-xl bg-white p-8 rounded-xl shadow-lg text-center">
        <h2 className="text-2xl font-bold mb-4 text-green-700">Your Personality Insight</h2>
        <p className="text-gray-800 text-lg">{summary}</p>
      </div>
    </div>
  );
}