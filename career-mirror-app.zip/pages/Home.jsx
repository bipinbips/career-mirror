import { useNavigate } from 'react-router-dom';

export default function Home() {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-r from-blue-500 to-indigo-600 text-white">
      <h1 className="text-4xl font-bold mb-4">Career Mirror</h1>
      <p className="mb-6 text-center max-w-md">
        Discover your personality traits and unlock the best career paths suited for your nature.
      </p>
      <button
        onClick={() => navigate('/assessment')}
        className="px-6 py-3 bg-white text-blue-600 rounded-xl font-semibold hover:bg-gray-200 transition"
      >
        Start Assessment
      </button>
    </div>
  );
}