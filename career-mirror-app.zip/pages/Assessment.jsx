import { useNavigate } from 'react-router-dom';
import { useState } from 'react';

const questions = [
  {
    question: 'How do you react to challenges?',
    options: ['Stay calm', 'Get angry', 'Try again', 'Lose hope'],
  },
  {
    question: 'How often do you help others?',
    options: ['Always', 'Sometimes', 'Rarely', 'Never'],
  },
  {
    question: 'How do you make decisions?',
    options: ['Logically', 'Emotionally', 'By asking others', 'Randomly'],
  },
  {
    question: 'How disciplined are you with time?',
    options: ['Very', 'Average', 'Not much', 'Not at all'],
  },
  {
    question: 'How do you handle failure?',
    options: ['Learn and move on', 'Get demotivated', 'Try again', 'Blame others'],
  },
];

export default function Assessment() {
  const navigate = useNavigate();
  const [answers, setAnswers] = useState(Array(questions.length).fill(''));

  const handleChange = (index, value) => {
    const newAnswers = [...answers];
    newAnswers[index] = value;
    setAnswers(newAnswers);
  };

  const handleSubmit = () => {
    if (answers.includes('')) {
      alert('Please answer all questions.');
    } else {
      localStorage.setItem('careerAnswers', JSON.stringify(answers));
      navigate('/result');
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <h2 className="text-3xl font-bold text-center mb-8 text-indigo-700">Personality Assessment</h2>
      <div className="max-w-2xl mx-auto bg-white p-6 rounded-xl shadow-md">
        {questions.map((q, idx) => (
          <div key={idx} className="mb-6">
            <label className="block font-semibold mb-2">
              {idx + 1}. {q.question}
            </label>
            <select
              value={answers[idx]}
              onChange={(e) => handleChange(idx, e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md"
            >
              <option value="">-- Select an option --</option>
              {q.options.map((opt, i) => (
                <option key={i} value={opt}>{opt}</option>
              ))}
            </select>
          </div>
        ))}
        <button
          onClick={handleSubmit}
          className="w-full bg-indigo-600 text-white py-2 px-4 rounded-xl hover:bg-indigo-700"
        >
          Submit
        </button>
      </div>
    </div>
  );
}